SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

print_modname() {
ui_print "
 ****************************
 - 模块: $MODNAME
 - 模块ID: $MODID
 - 作者: $MODAUTHOR
 - 介绍: $MODdescription
 ****************************
 - 设备相关信息↓
 - SDK: $Sdk
 - 设备: $Device
 - 设备代号: $device
 - 安卓版本: Android $Android
 - MIUI版本: $MIUI  $Version
 ****************************
 "
}


set_perm_recursive  $MODPATH  0  0  0755  0644


AUTOMOUNT=true

MOD_Version="`grep_prop version $TMPDIR/module.prop`"
MOD_Author="`grep_prop author $TMPDIR/module.prop`"
MOD_Description="`grep_prop description $TMPDIR/module.prop`"
MarketName="`getprop ro.product.marketname`"
Device="`getprop ro.product.device`"
Model="`getprop ro.product.model`"
MIUI="`getprop ro.miui.ui.version.name`"
Version="`getprop ro.build.version.incremental`"
Android="`getprop ro.build.version.release`"
za=$MODPATH/YuK/7za #$za a -tzip -mx=7 -mmt
